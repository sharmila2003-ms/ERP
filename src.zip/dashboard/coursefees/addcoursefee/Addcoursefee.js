import React, { useContext, useState } from "react";
import AuthContext from "../../../services/AuthContext";
// import "./addcoursefee.css";

const Addcoursefee = (props) => {

    const { insert } = useContext(AuthContext);

    const [validated, setValidated] = useState(false);
    const [error, setError] = useState("");
    const [success, setSuccess] = useState("");
    const [loading, setLoading] = useState(false);

    const courses = props.courses || [];


    const handleSubmit = async (e) => {

        e.preventDefault();

        const form = e.currentTarget;

        setError("");
        setSuccess("");


        // =========================
        // FORM VALIDATION
        // =========================

        if (!form.checkValidity()) {

            e.stopPropagation();

            setValidated(true);

            return;
        }


        // =========================
        // GET FORM DATA
        // =========================

        const courseId =
            form.Course_id.value;

        const courseFees =
            form.Course_Fees.value;

        const duration =
            form.Duration.value;

        const durationType =
            form.Duration_Type.value;

        const status =
            form.Status.value;


        // =========================
        // COURSE FEE DATA
        // =========================

        const courseFeeData = {

            Course_id: parseInt(courseId, 10),

            Course_Fees: parseFloat(courseFees),

            Duration: parseInt(duration, 10),

            Duration_Type: durationType,

            Status: status,

        };


        console.log(
            "Sending Course Fee:",
            courseFeeData
        );


        try {

            setLoading(true);


            // =========================
            // INSERT
            // =========================

            const response = await insert(
                courseFeeData,
                "coursefee_create"
            );


            console.log(
                "Course Fee created:",
                response
            );


            // =========================
            // SUCCESS
            // =========================

            setSuccess(
    "Course fee plan created successfully!"
);


// Clear form
form.reset();

setValidated(false);


// Refresh parent list
if (props.onSuccess) {

    await props.onSuccess();

}


        } catch (error) {

            console.error(
                "Course fee creation error:",
                error
            );


            // =========================
            // DJANGO ERROR
            // =========================

            const responseData =
                error.responseData;


            console.log(
                "Django Error:",
                responseData
            );


            // Detail error
            if (
                responseData &&
                responseData.detail
            ) {

                setError(
                    responseData.detail
                );

            }

            // Other server error
            else {

                setError(
                    "Course fee plan could not be created. Please try again."
                );
            }

        } finally {

            setLoading(false);

        }

    };


return (

    <div className="coursefee-page centered-form-page container-xxl flex-grow-1 container-p-y">

        <div className="centered-form-wrap">


            {/* ================================================= */}
            {/* HEADER */}
            {/* ================================================= */}

            <div className="page-header">

                <div>

                    <h3 className="page-title">
                        Add Course Fee
                    </h3>

                    <p className="page-subtitle">
                        Create a new fee and duration plan for a course
                    </p>

                </div>


                <button
                    type="button"
                    className="btn btn-outline-secondary add-btn"
                    onClick={props.toggle}
                >

                    <i className="bx bx-arrow-back me-2"></i>

                    Back to List

                </button>

            </div>


            {/* ================================================= */}
            {/* FORM CARD */}
            {/* ================================================= */}

            <div className="card coursefee-card add-coursefee-card">

                <div className="card-body">

                    {/* SUCCESS */}
                    {success && (
                        <div
                            className="alert alert-success"
                            role="alert"
                        >
                            <strong>Success!</strong>{" "}
                            {success}
                        </div>
                    )}

                    {/* ERROR */}
                    {error && (
                        <div
                            className="alert alert-danger"
                            role="alert"
                        >
                            <strong>Error!</strong>{" "}
                            {error}
                        </div>
                    )}

                    <form
                        onSubmit={handleSubmit}
                        noValidate
                        className={
                            validated ? "was-validated" : ""
                        }
                    >

                        {/* SELECT COURSE + COURSE FEES — one row, two columns */}
                        <div className="row">

                            <div className="col-md-6 mb-3">

                                <label
                                    htmlFor="Course_id"
                                    className="form-label"
                                >
                                    Select Course
                                </label>

                                <select
                                    id="Course_id"
                                    name="Course_id"
                                    className="form-select"
                                    required
                                    defaultValue=""
                                >

                                    <option value="" disabled>
                                        Select Course
                                    </option>

                                    {courses.map((course) => (

                                        <option
                                            key={course.Course_id}
                                            value={course.Course_id}
                                        >
                                            {course.Course_name}
                                        </option>

                                    ))}

                                </select>

                                <div className="invalid-feedback">
                                    Please select a course.
                                </div>

                            </div>


                            <div className="col-md-6 mb-3">

                                <label
                                    htmlFor="Course_Fees"
                                    className="form-label"
                                >
                                    Course Fees
                                </label>

                                <input
                                    type="number"
                                    name="Course_Fees"
                                    id="Course_Fees"
                                    className="form-control"
                                    placeholder="e.g. 25000"
                                    required
                                    min="0"
                                    step="0.01"
                                />

                                <div className="invalid-feedback">
                                    Please enter a valid fee amount.
                                </div>

                            </div>

                        </div>


                        {/* DURATION + DURATION TYPE + STATUS — one row, three columns */}
                        <div className="row">

                            <div className="col-md-4 mb-3">

                                <label
                                    htmlFor="Duration"
                                    className="form-label"
                                >
                                    Duration
                                </label>

                                <input
                                    type="number"
                                    name="Duration"
                                    id="Duration"
                                    className="form-control"
                                    placeholder="e.g. 4"
                                    required
                                    min="1"
                                    step="1"
                                />

                                <div className="invalid-feedback">
                                    Please enter a valid duration.
                                </div>

                            </div>


                            <div className="col-md-4 mb-3">

                                <label
                                    htmlFor="Duration_Type"
                                    className="form-label"
                                >
                                    Duration Type
                                </label>

                                <select
                                    id="Duration_Type"
                                    name="Duration_Type"
                                    className="form-select"
                                    required
                                    defaultValue=""
                                >

                                    <option value="" disabled>
                                        Select Type
                                    </option>

                                    <option value="Days">
                                        Days
                                    </option>

                                    <option value="Months">
                                        Months
                                    </option>

                                    <option value="Years">
                                        Years
                                    </option>

                                </select>

                                <div className="invalid-feedback">
                                    Please select a duration type.
                                </div>

                            </div>


                            <div className="col-md-4 mb-3">

                                <label
                                    htmlFor="Status"
                                    className="form-label"
                                >
                                    Status
                                </label>

                                <select
                                    id="Status"
                                    name="Status"
                                    className="form-select"
                                    required
                                    defaultValue=""
                                >

                                    <option value="" disabled>
                                        Select Status
                                    </option>

                                    <option value="Active">
                                        Active
                                    </option>

                                    <option value="Inactive">
                                        Inactive
                                    </option>

                                </select>

                                <div className="invalid-feedback">
                                    Please select status.
                                </div>

                            </div>

                        </div>


                        {/* FOOTER BUTTONS */}
                        <div className="d-flex justify-content-end gap-2 mt-4">

                            <button
                                type="button"
                                className="btn btn-outline-secondary"
                                onClick={props.toggle}
                                disabled={loading}
                            >
                                Cancel
                            </button>

                            <button
                                type="submit"
                                className="btn btn-primary"
                                disabled={loading}
                            >

                                {loading ? (
                                    <>
                                        <span
                                            className="spinner-border spinner-border-sm me-2"
                                            role="status"
                                            aria-hidden="true"
                                        ></span>

                                        Saving...
                                    </>
                                ) : (
                                    "Save"
                                )}

                            </button>

                        </div>

                    </form>

                </div>

            </div>

        </div>

    </div>

);
};


export default Addcoursefee;
