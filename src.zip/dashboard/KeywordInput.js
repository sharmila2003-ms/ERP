import React, { useEffect, useRef, useState } from "react";

export const DESCRIPTION_KEYWORDS = ["Frontend", "Database", "Backend", "Others"];

/*
 * Type-to-choose keyword box.
 *  - Whatever letters are typed, the four keywords are always listed.
 *  - Only a keyword CLICKED (or picked with arrow keys + Enter) is stored.
 *  - Typed text that is not chosen is discarded when the box loses focus.
 *  - A hidden input carries the chosen value so the form can read
 *    form.CourseModule_Description.value as before.
 */
const KeywordInput = ({ value, onChange, name = "CourseModule_Description", id = "CourseModule_Description" }) => {

    const [text, setText] = useState(value || "");
    const [open, setOpen] = useState(false);
    const [active, setActive] = useState(-1);
    const wrapRef = useRef(null);

    // keep the visible text in sync with the chosen value
    useEffect(() => {
        setText(value || "");
    }, [value]);

    const choose = (keyword) => {
        onChange(keyword);
        setText(keyword);
        setOpen(false);
        setActive(-1);
    };

    const handleBlur = (e) => {
        if (wrapRef.current && wrapRef.current.contains(e.relatedTarget)) {
            return;
        }
        // leaving the box: drop anything typed that was not chosen
        setText(value || "");
        setOpen(false);
        setActive(-1);
    };

    const handleKeyDown = (e) => {
        if (e.key === "ArrowDown") {
            e.preventDefault();
            setOpen(true);
            setActive((a) => (a + 1) % DESCRIPTION_KEYWORDS.length);
        } else if (e.key === "ArrowUp") {
            e.preventDefault();
            setOpen(true);
            setActive((a) => (a <= 0 ? DESCRIPTION_KEYWORDS.length - 1 : a - 1));
        } else if (e.key === "Enter") {
            if (open && active >= 0) {
                e.preventDefault();
                choose(DESCRIPTION_KEYWORDS[active]);
            } else if (open) {
                e.preventDefault();
            }
        } else if (e.key === "Escape") {
            setText(value || "");
            setOpen(false);
            setActive(-1);
        }
    };

    return (
        <div className="keyword-box" ref={wrapRef} onBlur={handleBlur}>

            <input type="hidden" name={name} value={value || ""} />

            <input
                type="text"
                id={id}
                className="form-control"
                placeholder="Type and choose a keyword"
                autoComplete="off"
                value={text}
                required
                onFocus={() => setOpen(true)}
                onChange={(e) => {
                    setText(e.target.value);
                    setOpen(true);
                    setActive(-1);
                }}
                onKeyDown={handleKeyDown}
            />

            {open && (
                <ul className="keyword-list" role="listbox">
                    {DESCRIPTION_KEYWORDS.map((keyword, i) => (
                        <li key={keyword}>
                            <button
                                type="button"
                                role="option"
                                aria-selected={keyword === value}
                                className={
                                    "keyword-option" +
                                    (i === active ? " is-active" : "") +
                                    (keyword === value ? " is-selected" : "")
                                }
                                onMouseDown={(e) => e.preventDefault()}
                                onClick={() => choose(keyword)}
                            >
                                {keyword}
                            </button>
                        </li>
                    ))}
                </ul>
            )}

        </div>
    );
};

export default KeywordInput;
