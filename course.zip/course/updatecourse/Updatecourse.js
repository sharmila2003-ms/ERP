import React, { useContext, useState } from "react";
import AuthContext from "../../../services/AuthContext";

const CATEGORIES = ["Frontend", "Database", "Backend", "Others"];

// Course modules switched to Deactive on the Course Module page
// must not be offered in "Select Modules".
const isModuleActive = (m) =>
    m.CourseModule_Status !== "Deactive" &&
    m.CourseModule_Status !== "Inactive";

const Updatecourse = (props) => {

    const { update } = useContext(AuthContext);

    const course = props.data || {};

    // Only Active course modules can be selected
    const courseModules = (props.courseModules || []).filter(isModuleActive);

    const [validated, setValidated] = useState(false);
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);

    // Modules this course already has
    // Modules this course already has — Deactive ones are dropped
    // because they are no longer shown in the list.
    const activeIds = courseModules.map((m) => m.CourseModule_id);

    const initialModules = (
        Array.isArray(course.Course_Modules)
            ? course.Course_Modules
            : []
    ).filter((id) => activeIds.includes(id));

    const [selectedModules, setSelectedModules] = useState(initialModules);

    // Course status buttons — start from the saved status (Active if none)
    const [courseStatus, setCourseStatus] = useState(
        course.Course_Status === "Active" || !course.Course_Status
            ? "Active"
            : "Deactive"
    );

    // Pre-tick every category that already has a selected module
    const [selectedCategories, setSelectedCategories] = useState(() =>
        CATEGORIES.filter((category) =>
            courseModules.some(
                (m) =>
                    m.CourseModule_category === category &&
                    initialModules.includes(m.CourseModule_id)
            )
        )
    );

    const modulesOfCategory = (category) =>
        courseModules.filter((m) => m.CourseModule_category === category);


    // =====================================================
    // TOGGLE A CATEGORY
    // =====================================================

    const toggleCategory = (category) => {

        if (selectedCategories.includes(category)) {

            // Un-ticking a category also drops its modules from the selection
            const ids = modulesOfCategory(category).map(
                (m) => m.CourseModule_id
            );

            setSelectedModules((prev) =>
                prev.filter((id) => !ids.includes(id))
            );

            setSelectedCategories((prev) =>
                prev.filter((c) => c !== category)
            );

        } else {

            setSelectedCategories((prev) => [...prev, category]);

        }

    };


    // =====================================================
    // TOGGLE A MODULE CHECKBOX
    // =====================================================

    const toggleModule = (moduleId) => {

        setSelectedModules((prev) =>

            prev.includes(moduleId)
                ? prev.filter((id) => id !== moduleId)
                : [...prev, moduleId]

        );

    };


    // =====================================================
    // SUBMIT
    // =====================================================

    const handleSubmit = async (e) => {

        e.preventDefault();

        const form = e.currentTarget;

        setError("");

        if (!form.checkValidity()) {

            e.stopPropagation();

            setValidated(true);

            return;
        }

        const courseName = form.Course_name.value.trim();

        const courseCode = form.Course_Code.value.trim();

        if (courseName.length < 2) {

            setError("Course name must contain at least 2 characters.");

            setValidated(true);

            return;
        }

        if (selectedModules.length === 0) {

            setError("Please select at least one module for this course.");

            return;
        }

        const courseData = {
            Course_id: course.Course_id,
            Course_name: courseName,
            Course_Code: courseCode,
            Course_Status: courseStatus,
            Course_Modules: selectedModules
        };

        console.log(courseData);

        try {

            setLoading(true);

            await update(
                courseData,
                "update_course_datail",
                "/course"
            );

            // Refresh the list and go back to it
            if (props.onSuccess) {

                await props.onSuccess();

            } else {

                props.toggle();

            }

        } catch (err) {

            console.error("Update operation failed:", err);

            const responseData = err && err.responseData;

            if (responseData && responseData.Course_name) {

                setError(
                    Array.isArray(responseData.Course_name)
                        ? responseData.Course_name[0]
                        : responseData.Course_name
                );

            } else if (responseData && responseData.Course_Code) {

                setError(
                    Array.isArray(responseData.Course_Code)
                        ? responseData.Course_Code[0]
                        : responseData.Course_Code
                );

            } else if (responseData && responseData.detail) {

                setError(responseData.detail);

            } else {

                setError("Course could not be updated. Please try again.");

            }

        } finally {

            setLoading(false);

        }

    };


    return (

        <div className="course-page centered-form-page container-xxl flex-grow-1 container-p-y">

            <div className="centered-form-wrap">


                {/* HEADER */}

                <div className="page-header">

                    <div>

                        <h3 className="page-title">
                            Update Course
                        </h3>

                        <p className="page-subtitle">
                            Edit course details and modules
                        </p>

                    </div>

                    <button
                        type="button"
                        className="btn btn-outline-secondary add-btn"
                        onClick={props.toggle}
                    >

                        <i className="bx bx-arrow-back me-2"></i>

                        Back to List

                    </button>

                </div>


                {/* FORM CARD */}

                <div className="card course-card add-course-card">

                    <div className="card-body">

                        {/* ERROR */}
                        {error && (
                            <div
                                className="alert alert-danger"
                                role="alert"
                            >
                                <strong>Error!</strong>{" "}
                                {error}
                            </div>
                        )}

                        <form
                            onSubmit={handleSubmit}
                            noValidate
                            className={validated ? "was-validated" : ""}
                        >

                            {/* COURSE NAME + COURSE CODE */}
                            <div className="row">

                                <div className="col-md-6 mb-3">

                                    <label
                                        htmlFor="Course_name"
                                        className="form-label"
                                    >
                                        Course Name
                                    </label>

                                    <input
                                        type="text"
                                        name="Course_name"
                                        id="Course_name"
                                        className="form-control"
                                        placeholder="e.g. Full Stack Java"
                                        defaultValue={course.Course_name}
                                        required
                                        minLength="2"
                                        maxLength="255"
                                    />

                                    <div className="invalid-feedback">
                                        Please enter a valid course name.
                                    </div>

                                </div>


                                <div className="col-md-6 mb-3">

                                    <label
                                        htmlFor="Course_Code"
                                        className="form-label"
                                    >
                                        Course Code
                                    </label>

                                    <input
                                        type="text"
                                        name="Course_Code"
                                        id="Course_Code"
                                        className="form-control"
                                        placeholder="e.g. FS-JAVA"
                                        defaultValue={course.Course_Code}
                                        required
                                        minLength="2"
                                        maxLength="30"
                                    />

                                    <div className="invalid-feedback">
                                        Please enter a valid course code.
                                    </div>

                                </div>

                            </div>


                            {/* CATEGORY CHECKBOXES */}
                            <div className="mb-3">

                                <label className="form-label">
                                    Category
                                </label>

                                <div className="module-checkbox-group">

                                    {CATEGORIES.map((category) => (

                                        <div
                                            className="form-check"
                                            key={category}
                                        >

                                            <input
                                                type="checkbox"
                                                className="form-check-input"
                                                id={`edit-category-${category}`}
                                                checked={selectedCategories.includes(category)}
                                                onChange={() => toggleCategory(category)}
                                            />

                                            <label
                                                className="form-check-label"
                                                htmlFor={`edit-category-${category}`}
                                            >
                                                {category}
                                            </label>

                                        </div>

                                    ))}

                                </div>

                            </div>


                            {/* SELECT MODULES — one column per ticked category */}
                            <div className="mb-3">

                                <label className="form-label">
                                    Select Modules
                                </label>

                                {selectedCategories.length === 0 ? (

                                    <p className="text-muted mb-0">
                                        Tick a category above to choose its modules.
                                    </p>

                                ) : (

                                    <div className="module-category-cols">

                                        {CATEGORIES
                                            .filter((c) => selectedCategories.includes(c))
                                            .map((category) => {

                                                const mods = modulesOfCategory(category);

                                                return (

                                                    <div
                                                        className="module-category-col"
                                                        key={category}
                                                    >

                                                        <div className="module-category-title">
                                                            {category}
                                                        </div>

                                                        <div className="module-col-list">

                                                            {mods.length > 0 ? (

                                                                mods.map((module) => (

                                                                    <div
                                                                        className="form-check"
                                                                        key={module.CourseModule_id}
                                                                    >

                                                                        <input
                                                                            type="checkbox"
                                                                            className="form-check-input"
                                                                            id={`edit-module-${module.CourseModule_id}`}
                                                                            checked={selectedModules.includes(
                                                                                module.CourseModule_id
                                                                            )}
                                                                            onChange={() =>
                                                                                toggleModule(
                                                                                    module.CourseModule_id
                                                                                )
                                                                            }
                                                                        />

                                                                        <label
                                                                            className="form-check-label"
                                                                            htmlFor={`edit-module-${module.CourseModule_id}`}
                                                                        >
                                                                            {module.CourseModule_name}
                                                                        </label>

                                                                    </div>

                                                                ))

                                                            ) : (

                                                                <p className="text-muted mb-0">
                                                                    No modules in this category.
                                                                </p>

                                                            )}

                                                        </div>

                                                    </div>

                                                );

                                            })}

                                    </div>

                                )}

                            </div>


                        {/* COURSE STATUS — two buttons, no icons */}
                        <div className="mb-3">

                            <label className="form-label">
                                Status
                            </label>

                            <div
                                className="course-status-toggle"
                                role="group"
                                aria-label="Course status"
                            >

                                <button
                                    type="button"
                                    className={`course-status-btn${
                                        courseStatus === "Active" ? " active-on" : ""
                                    }`}
                                    aria-pressed={courseStatus === "Active"}
                                    onClick={() => setCourseStatus("Active")}
                                >
                                    Active
                                </button>

                                <button
                                    type="button"
                                    className={`course-status-btn${
                                        courseStatus === "Deactive" ? " deactive-on" : ""
                                    }`}
                                    aria-pressed={courseStatus === "Deactive"}
                                    onClick={() => setCourseStatus("Deactive")}
                                >
                                    Deactive
                                </button>

                            </div>

                        </div>


                            {/* FOOTER BUTTONS */}
                            <div className="d-flex justify-content-end gap-2 mt-4">

                                <button
                                    type="button"
                                    className="btn btn-outline-secondary"
                                    onClick={props.toggle}
                                    disabled={loading}
                                >
                                    Cancel
                                </button>

                                <button
                                    type="submit"
                                    className="btn btn-primary"
                                    disabled={loading}
                                >

                                    {loading ? (
                                        <>
                                            <span
                                                className="spinner-border spinner-border-sm me-2"
                                                role="status"
                                                aria-hidden="true"
                                            ></span>

                                            Updating...
                                        </>
                                    ) : (
                                        "Update Course"
                                    )}

                                </button>

                            </div>

                        </form>

                    </div>

                </div>

            </div>

        </div>

    );
};

export default Updatecourse;
