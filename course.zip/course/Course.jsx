import React, {
    useState,
    useContext,
    useEffect,
    useCallback
} from "react";

import "./Course.css";

import Addcourse from "./addcourse/Addcourse";
import Updatecourse from "./updatecourse/Updatecourse";
import Deletecourse from "./deletecourse/Deletecourse";
import Viewcourse from "./viewcourse/Viewcourse";

import AuthContext from "../../services/AuthContext";


function Course() {

    const [addPopupVisible, setAddPopupVisible] = useState(false);
    const [updatePopupVisible, setUpdatePopupVisible] = useState(false);
    const [deletePopupVisible, setDeletePopupVisible] = useState(false);

    const [currentPage, setCurrentPage] = useState(1);

    const { getData, update } = useContext(AuthContext);

    const [courses, setCourses] = useState([]);

    const [courseModules, setCourseModules] = useState([]);

    const [value, setValue] = useState(null);

    // Course currently shown on the View page (null = list page)
    const [viewCourse, setViewCourse] = useState(null);


    // =====================================================
    // FETCH COURSES
    // =====================================================

    const fetchCourses = useCallback(async () => {

        try {

            const data = await getData(
                "fetch_course_datail"
            );

            console.log(
                "Courses fetched:",
                data
            );

            if (Array.isArray(data)) {

                setCourses(data);

            } else {

                setCourses([]);

            }

        } catch (err) {

            console.error(
                "Failed to fetch courses:",
                err
            );

        }

    }, [getData]);


    // =====================================================
    // FETCH COURSE MODULES (for badges + checkbox list)
    // =====================================================

    const fetchCourseModules = useCallback(async () => {

        try {

            const data = await getData(
                "fetch_coursemodule_datail"
            );

            if (Array.isArray(data)) {

                setCourseModules(data);

            } else {

                setCourseModules([]);

            }

        } catch (err) {

            console.error(
                "Failed to fetch course modules:",
                err
            );

        }

    }, [getData]);


    // =====================================================
    // INITIAL LOAD
    // =====================================================

    useEffect(() => {

        fetchCourses();

        fetchCourseModules();

    }, [fetchCourses, fetchCourseModules]);


    // =====================================================
    // ADD PAGE (no longer a popup — swaps the course list
    // for the Addcourse page directly)
    // =====================================================

    const toggleAddPopup = () => {

        setAddPopupVisible(
            !addPopupVisible
        );

    };


    // =====================================================
    // UPDATE POPUP
    // =====================================================

    const toggleUpdatePopup = () => {

        setUpdatePopupVisible(
            !updatePopupVisible
        );

    };


    // =====================================================
    // DELETE POPUP
    // =====================================================

    const toggleDeletePopup = () => {

        setDeletePopupVisible(
            !deletePopupVisible
        );

    };


    // =====================================================
    // AFTER COURSE UPDATED
    // =====================================================

    const handleCourseUpdated = async () => {

        await fetchCourses();

        setUpdatePopupVisible(false);

    };


    // =====================================================
    // AFTER COURSE CREATED
    // =====================================================

    const handleCourseCreated = async () => {

        console.log(
            "New course created. Refreshing list..."
        );

        // Fetch latest data from Django
        await fetchCourses();

        // Close popup
        setAddPopupVisible(false);

        // Go back to first page
        setCurrentPage(1);

    };


    // =====================================================
    // PAGINATION
    // =====================================================

    const itemsPerPage = 4;

    const indexOfLastItem =
        currentPage * itemsPerPage;

    const indexOfFirstItem =
        indexOfLastItem - itemsPerPage;

    const currentCourses =
        courses.slice(
            indexOfFirstItem,
            indexOfLastItem
        );


    const nextPage = () => {

        if (
            indexOfLastItem <
            courses.length
        ) {

            setCurrentPage(
                currentPage + 1
            );

        }

    };


    const prevPage = () => {

        if (currentPage > 1) {

            setCurrentPage(
                currentPage - 1
            );

        }

    };


    // =====================================================
    // UPDATE
    // =====================================================

    const handleUpdate = (course) => {

        setValue(course);

        toggleUpdatePopup();

    };


    // =====================================================
    // DELETE
    // =====================================================

    const handleDelete = (id) => {

        setValue(id);

        toggleDeletePopup();

    };


    // =====================================================
    // HELPER: COUNT MODULES OF A COURSE
    // =====================================================

    const getModuleCount = (course) => {

        return Array.isArray(course.Course_Modules)
            ? course.Course_Modules.length
            : 0;

    };


    // =====================================================
    // VIEW POPUP
    // =====================================================

    const handleView = (course) => {

        setViewCourse(course);

    };

    const closeView = () => {

        setViewCourse(null);

    };


    // =====================================================
    // STATUS BUTTON (Active / Deactive — click to switch)
    // A course with no saved status counts as Active.
    // =====================================================

    const isCourseActive = (course) =>
        !course.Course_Status || course.Course_Status === "Active";

    const handleToggleStatus = async (course) => {

        const newStatus = isCourseActive(course) ? "Deactive" : "Active";

        const payload = {
            Course_id: course.Course_id,
            Course_name: course.Course_name,
            Course_Code: course.Course_Code,
            Course_Status: newStatus,
            Course_Modules: Array.isArray(course.Course_Modules)
                ? course.Course_Modules
                : [],
        };

        try {

            await update(
                payload,
                "update_course_datail",
                "/course"
            );

            await fetchCourses();

        } catch (err) {

            console.error(
                "Failed to toggle status:",
                err
            );

        }

    };


    // =====================================================
    // ADD PAGE VIEW
    // =====================================================
    // Swap the whole list out for the Addcourse page —
    // rendered directly in the page, no modal/backdrop.

    if (addPopupVisible) {

        return (

            <Addcourse
                toggle={toggleAddPopup}
                onSuccess={handleCourseCreated}
                courseModules={courseModules}
            />

        );

    }


    // =====================================================
    // EDIT PAGE VIEW (same page layout as Add Course)
    // =====================================================

    if (updatePopupVisible) {

        return (

            <Updatecourse
                toggle={toggleUpdatePopup}
                onSuccess={handleCourseUpdated}
                data={value}
                courseModules={courseModules}
            />

        );

    }


    return (

        <div className="course-page container-xxl flex-grow-1 container-p-y">


            {/* ================================================= */}
            {/* HEADER */}
            {/* ================================================= */}

            <div className="page-header">

                <div>

                    <h3 className="page-title">
                        Course Management
                    </h3>

                    <p className="page-subtitle">
                        Manage all available courses
                    </p>

                </div>


                <button
                    className="btn btn-primary add-btn"
                    onClick={toggleAddPopup}
                >

                    <i className="bx bx-plus me-2"></i>

                    Add Course

                </button>

            </div>


            {/* ================================================= */}
            {/* COURSE TABLE */}
            {/* ================================================= */}

            <div className="card course-card">

                <div className="table-responsive">

                    <table className="table modern-table">

                        <thead>

                            <tr>

                                <th>ID</th>

                                <th>
                                    Course Name
                                </th>

                                <th>
                                    Course Code
                                </th>

                                <th>
                                    Modules
                                </th>

                                <th>
                                    Created Date
                                </th>

                                <th>
                                    Status
                                </th>

                                <th width="180">
                                    Action
                                </th>

                            </tr>

                        </thead>


                        <tbody>

                            {currentCourses.length > 0 ? (

                                currentCourses.map(
                                    (course) => (

                                        <tr
                                            key={
                                                course.Course_id
                                            }
                                        >

                                            <td>
                                                #{course.Course_id}
                                            </td>


                                            <td>

                                                <strong>
                                                    {
                                                        course.Course_name
                                                    }
                                                </strong>

                                            </td>


                                            <td>

                                                {
                                                    course.Course_Code
                                                }

                                            </td>


                                            <td>

                                                <div className="module-cell">

                                                    <span className="module-count">
                                                        {
                                                            getModuleCount(course)
                                                        }
                                                    </span>

                                                    <button
                                                        className="btn btn-view"
                                                        onClick={() =>
                                                            handleView(
                                                                course
                                                            )
                                                        }
                                                    >
                                                        <i className="bx bx-show me-1"></i>
                                                        View
                                                    </button>

                                                </div>

                                            </td>


                                            <td>

                                                {
                                                    course.Create_date
                                                        ? new Date(
                                                              course.Create_date
                                                          ).toLocaleDateString()
                                                        : "-"
                                                }

                                            </td>


                                            <td>

                                                <button
                                                    type="button"
                                                    className={
                                                        isCourseActive(course)
                                                            ? "course-status-switch active"
                                                            : "course-status-switch inactive"
                                                    }
                                                    onClick={() =>
                                                        handleToggleStatus(course)
                                                    }
                                                    title="Click to switch status"
                                                >

                                                    {
                                                        isCourseActive(course)
                                                            ? "Active"
                                                            : "Deactive"
                                                    }

                                                </button>

                                            </td>


                                            <td>

                                                <div className="action-buttons">

                                                    <button
                                                        className="btn btn-edit"
                                                        onClick={() =>
                                                            handleUpdate(
                                                                course
                                                            )
                                                        }
                                                    >
                                                        Edit
                                                    </button>


                                                    <button
                                                        className="btn btn-delete"
                                                        onClick={() =>
                                                            handleDelete(
                                                                course.Course_id
                                                            )
                                                        }
                                                    >
                                                        Delete
                                                    </button>

                                                </div>

                                            </td>

                                        </tr>

                                    )
                                )

                            ) : (

                                <tr>

                                    <td
                                        colSpan="7"
                                        className="text-center py-4"
                                    >

                                        No courses found.

                                    </td>

                                </tr>

                            )}

                        </tbody>

                    </table>

                </div>


                {/* ================================================= */}
                {/* UPDATE */}
                {/* ================================================= */}

                {/* ================================================= */}
                {/* VIEW POPUP */}
                {/* ================================================= */}

                {viewCourse && (

                    <Viewcourse
                        toggle={closeView}
                        data={viewCourse}
                        courseModules={courseModules}
                    />

                )}


                {/* ================================================= */}
                {/* DELETE */}
                {/* ================================================= */}

                {deletePopupVisible && (

                    <Deletecourse
                        toggle={toggleDeletePopup}
                        data={value}
                    />

                )}


                {/* ================================================= */}
                {/* PAGINATION */}
                {/* ================================================= */}

                <div className="card-footer bg-white border-0">

                    <div className="d-flex justify-content-end">

                        <button
                            className="btn btn-light me-2"
                            onClick={prevPage}
                            disabled={
                                currentPage === 1
                            }
                        >

                            <i className="bx bx-chevron-left"></i>

                            Previous

                        </button>


                        <button
                            className="btn btn-primary"
                            onClick={nextPage}
                            disabled={
                                indexOfLastItem >=
                                courses.length
                            }
                        >

                            Next

                            <i className="bx bx-chevron-right ms-1"></i>

                        </button>

                    </div>

                </div>

            </div>

        </div>

    );

}


export default Course;
