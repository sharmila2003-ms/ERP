import React, { useContext, useState } from "react";
import AuthContext from "../../../services/AuthContext";
// import "./addcourse.css";

// Course modules switched to Deactive on the Course Module page
// must not be offered in "Select Modules".
const isModuleActive = (m) =>
    m.CourseModule_Status !== "Deactive" &&
    m.CourseModule_Status !== "Inactive";

const Addcourse = (props) => {

    const { insert } = useContext(AuthContext);

    const [validated, setValidated] = useState(false);
    const [error, setError] = useState("");
    const [success, setSuccess] = useState("");
    const [loading, setLoading] = useState(false);

    // Selected CourseModule_id values (checkbox group)
    const [selectedModules, setSelectedModules] = useState([]);

    // Course status buttons — Active by default
    const [courseStatus, setCourseStatus] = useState("Active");

    // Only Active course modules can be selected
    const courseModules = (props.courseModules || []).filter(isModuleActive);

    // Category checkboxes: each ticked category gets its own column of modules
    const CATEGORIES = ["Frontend", "Database", "Backend", "Others"];

    const [selectedCategories, setSelectedCategories] = useState([]);

    const modulesOfCategory = (category) =>
        courseModules.filter((m) => m.CourseModule_category === category);

    const toggleCategory = (category) => {

        if (selectedCategories.includes(category)) {

            // Un-ticking a category also drops its modules from the selection
            const ids = modulesOfCategory(category).map(
                (m) => m.CourseModule_id
            );

            setSelectedModules((prev) =>
                prev.filter((id) => !ids.includes(id))
            );

            setSelectedCategories((prev) =>
                prev.filter((c) => c !== category)
            );

        } else {

            setSelectedCategories((prev) => [...prev, category]);

        }

    };


    // =====================================================
    // TOGGLE A MODULE CHECKBOX
    // =====================================================

    const toggleModule = (moduleId) => {

        setSelectedModules((prev) =>

            prev.includes(moduleId)
                ? prev.filter((id) => id !== moduleId)
                : [...prev, moduleId]

        );

    };


    const handleSubmit = async (e) => {

        e.preventDefault();

        const form = e.currentTarget;

        setError("");
        setSuccess("");


        // =========================
        // FORM VALIDATION
        // =========================

        if (!form.checkValidity()) {

            e.stopPropagation();

            setValidated(true);

            return;
        }


        // =========================
        // GET FORM DATA
        // =========================

        const courseName =
            form.Course_name.value.trim();

        const courseCode =
            form.Course_Code.value.trim();


        // =========================
        // COURSE NAME VALIDATION
        // =========================

        if (courseName.length < 2) {

            setError(
                "Course name must contain at least 2 characters."
            );

            setValidated(true);

            return;
        }


        // =========================
        // MODULE SELECTION VALIDATION
        // =========================

        if (selectedModules.length === 0) {

            setError(
                "Please select at least one module for this course."
            );

            return;
        }


        // =========================
        // COURSE DATA
        // =========================

        const courseData = {

            Course_name: courseName,

            Course_Code: courseCode,

            Course_Status: courseStatus,

            Course_Modules: selectedModules,

        };


        console.log(
            "Sending Course:",
            courseData
        );


        try {

            setLoading(true);


            // =========================
            // INSERT
            // =========================

            const response = await insert(
                courseData,
                "course_create"
            );


            console.log(
                "Course created:",
                response
            );


            // =========================
            // SUCCESS
            // =========================

            setSuccess(
    "Course created successfully!"
);


// Clear form
form.reset();

setSelectedModules([]);

setSelectedCategories([]);

setCourseStatus("Active");

setValidated(false);


// Refresh parent course list
if (props.onSuccess) {

    await props.onSuccess();

}


        } catch (error) {

            console.error(
                "Course creation error:",
                error
            );


            // =========================
            // DJANGO ERROR
            // =========================

            const responseData =
                error.responseData;


            console.log(
                "Django Error:",
                responseData
            );


            // Course name duplicate
            if (
                responseData &&
                responseData.Course_name
            ) {

                const message =
                    Array.isArray(
                        responseData.Course_name
                    )
                        ? responseData.Course_name[0]
                        : responseData.Course_name;


                setError(message);

            }

            // Course code duplicate
            else if (
                responseData &&
                responseData.Course_Code
            ) {

                const message =
                    Array.isArray(
                        responseData.Course_Code
                    )
                        ? responseData.Course_Code[0]
                        : responseData.Course_Code;


                setError(message);

            }

            // Detail error
            else if (
                responseData &&
                responseData.detail
            ) {

                setError(
                    responseData.detail
                );

            }

            // Other server error
            else {

                setError(
                    "Course could not be created. Please try again."
                );
            }

        } finally {

            setLoading(false);

        }

    };


return (

    <div className="course-page centered-form-page container-xxl flex-grow-1 container-p-y">

        <div className="centered-form-wrap">


            {/* ================================================= */}
            {/* HEADER */}
            {/* ================================================= */}

            <div className="page-header">

                <div>

                    <h3 className="page-title">
                        Add Course
                    </h3>

                    <p className="page-subtitle">
                        Create a new course
                    </p>

                </div>


                <button
                    type="button"
                    className="btn btn-outline-secondary add-btn"
                    onClick={props.toggle}
                >

                    <i className="bx bx-arrow-back me-2"></i>

                    Back to List

                </button>

            </div>


            {/* ================================================= */}
            {/* FORM CARD */}
            {/* ================================================= */}

            <div className="card course-card add-course-card">

                <div className="card-body">

                    {/* SUCCESS */}
                    {success && (
                        <div
                            className="alert alert-success"
                            role="alert"
                        >
                            <strong>Success!</strong>{" "}
                            {success}
                        </div>
                    )}

                    {/* ERROR */}
                    {error && (
                        <div
                            className="alert alert-danger"
                            role="alert"
                        >
                            <strong>Error!</strong>{" "}
                            {error}
                        </div>
                    )}

                    <form
                        onSubmit={handleSubmit}
                        noValidate
                        className={
                            validated ? "was-validated" : ""
                        }
                    >

                        {/* COURSE NAME + COURSE CODE — one row, two columns */}
                        <div className="row">

                            <div className="col-md-6 mb-3">

                                <label
                                    htmlFor="Course_name"
                                    className="form-label"
                                >
                                    Course Name
                                </label>

                                <input
                                    type="text"
                                    name="Course_name"
                                    id="Course_name"
                                    className="form-control"
                                    placeholder="e.g. Full Stack Java"
                                    required
                                    minLength="2"
                                    maxLength="255"
                                />

                                <div className="invalid-feedback">
                                    Please enter a valid course name.
                                </div>

                            </div>


                            <div className="col-md-6 mb-3">

                                <label
                                    htmlFor="Course_Code"
                                    className="form-label"
                                >
                                    Course Code
                                </label>

                                <input
                                    type="text"
                                    name="Course_Code"
                                    id="Course_Code"
                                    className="form-control"
                                    placeholder="e.g. FS-JAVA"
                                    required
                                    minLength="2"
                                    maxLength="30"
                                />

                                <div className="invalid-feedback">
                                    Please enter a valid course code.
                                </div>

                            </div>

                        </div>


                        {/* CATEGORY CHECKBOXES (filter the module list) */}
                        <div className="mb-3">

                            <label className="form-label">
                                Category
                            </label>

                            <div className="module-checkbox-group">

                                {CATEGORIES.map((category) => (

                                    <div
                                        className="form-check"
                                        key={category}
                                    >

                                        <input
                                            type="checkbox"
                                            className="form-check-input"
                                            id={`category-${category}`}
                                            checked={selectedCategories.includes(category)}
                                            onChange={() => toggleCategory(category)}
                                        />

                                        <label
                                            className="form-check-label"
                                            htmlFor={`category-${category}`}
                                        >
                                            {category}
                                        </label>

                                    </div>

                                ))}

                            </div>

                        </div>


                        {/* SELECT MODULES — one column per ticked category */}
                        <div className="mb-3">

                            <label className="form-label">
                                Select Modules
                            </label>

                            {selectedCategories.length === 0 ? (

                                <p className="text-muted mb-0">
                                    Tick a category above to choose its modules.
                                </p>

                            ) : (

                                <div className="module-category-cols">

                                {CATEGORIES
                                    .filter((c) => selectedCategories.includes(c))
                                    .map((category) => {

                                        const mods = modulesOfCategory(category);

                                        return (

                                            <div
                                                className="module-category-col"
                                                key={category}
                                            >

                                                <div className="module-category-title">
                                                    {category}
                                                </div>

                                                <div className="module-col-list">

                                                    {mods.length > 0 ? (

                                                        mods.map((module) => (

                                                            <div
                                                                className="form-check"
                                                                key={module.CourseModule_id}
                                                            >

                                                                <input
                                                                    type="checkbox"
                                                                    className="form-check-input"
                                                                    id={`module-${module.CourseModule_id}`}
                                                                    checked={selectedModules.includes(
                                                                        module.CourseModule_id
                                                                    )}
                                                                    onChange={() =>
                                                                        toggleModule(
                                                                            module.CourseModule_id
                                                                        )
                                                                    }
                                                                />

                                                                <label
                                                                    className="form-check-label"
                                                                    htmlFor={`module-${module.CourseModule_id}`}
                                                                >
                                                                    {module.CourseModule_name}
                                                                </label>

                                                            </div>

                                                        ))

                                                    ) : (

                                                        <p className="text-muted mb-0">
                                                            No modules in this category.
                                                        </p>

                                                    )}

                                                </div>

                                            </div>

                                        );

                                    })}

                                </div>

                            )}

                        </div>


                        


                        


                        {/* FOOTER BUTTONS */}
                        <div className="d-flex justify-content-end gap-2 mt-4">

                            <button
                                type="button"
                                className="btn btn-outline-secondary"
                                onClick={props.toggle}
                                disabled={loading}
                            >
                                Cancel
                            </button>

                            <button
                                type="submit"
                                className="btn btn-primary"
                                disabled={loading}
                            >

                                {loading ? (
                                    <>
                                        <span
                                            className="spinner-border spinner-border-sm me-2"
                                            role="status"
                                            aria-hidden="true"
                                        ></span>

                                        Saving...
                                    </>
                                ) : (
                                    "Save Course"
                                )}

                            </button>

                        </div>

                    </form>

                </div>

            </div>

        </div>

    </div>

);
};


export default Addcourse;
