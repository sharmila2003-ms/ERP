import React from "react";

// Categories shown in this fixed order (1, 2, 3, 4 ...)
const CATEGORIES = ["Frontend", "Database", "Backend", "Others"];

const Viewcourse = (props) => {

    const course = props.data || {};

    const courseModules = props.courseModules || [];

    // CourseModule_id values that belong to this course
    const selectedIds = Array.isArray(course.Course_Modules)
        ? course.Course_Modules
        : [];

    // Any category that is not in the fixed list is appended at the end
    const extraCategories = [
        ...new Set(
            courseModules
                .map((m) => m.CourseModule_category)
                .filter((c) => c && !CATEGORIES.includes(c))
        ),
    ];

    const categoryRows = [...CATEGORIES, ...extraCategories];

    // Modules of a category that are part of THIS course
    const modulesOfCategory = (category) =>
        courseModules.filter(
            (m) =>
                m.CourseModule_category === category &&
                selectedIds.includes(m.CourseModule_id)
        );

    const categoriesUsed = categoryRows.filter(
        (c) => modulesOfCategory(c).length > 0
    ).length;


    return (

        <div
            className="modal fade show vc-backdrop"
            tabIndex="-1"
            role="dialog"
            style={{ display: "block" }}
            onClick={props.toggle}
        >

            <div
                className="modal-dialog modal-dialog-centered vc-dialog"
                role="document"
                onClick={(e) => e.stopPropagation()}
            >

                <div className="modal-content vc-content">

                    {/* FLOATING CLOSE (X) */}

                    <button
                        type="button"
                        className="vc-close-x"
                        onClick={props.toggle}
                        aria-label="Close"
                    >
                        <i className="bx bx-x"></i>
                    </button>


                    {/* HEADER */}

                    <div className="vc-header">

                        <div className="vc-header-icon">
                            <i className="bx bx-book-open"></i>
                        </div>

                        <div>
                            <h5 className="vc-title">
                                {course.Course_name} — Course
                            </h5>

                            <div className="vc-subtitle">
                                Modules covered in this course
                                <span className="vc-dot">•</span>
                                <span className="vc-code">
                                    {course.Course_Code}
                                </span>
                                <span
                                    className={
                                        course.Course_Status === "Active"
                                            ? "status active vc-status"
                                            : "status inactive vc-status"
                                    }
                                >
                                    {course.Course_Status}
                                </span>
                            </div>
                        </div>

                    </div>


                    {/* BODY — CATEGORY / MODULES TABLE */}

                    <div className="vc-table-wrap">

                        <table className="vc-table">

                            <thead>
                                <tr>
                                    <th className="vc-col-no">
                                        <i className="bx bx-hash"></i> No
                                    </th>
                                    <th className="vc-col-cat">
                                        <i className="bx bx-list-ul"></i> Category
                                    </th>
                                    <th>
                                        <i className="bx bx-book-content"></i> Modules
                                    </th>
                                </tr>
                            </thead>

                            <tbody>

                                {categoryRows.map((category, index) => {

                                    const mods = modulesOfCategory(category);

                                    return (

                                        <tr key={category}>

                                            <td>
                                                <span className="vc-num">
                                                    {index + 1}
                                                </span>
                                            </td>

                                            <td>
                                                <span className="vc-cat">
                                                    <i className="bx bx-bookmark"></i>
                                                    {category}
                                                </span>
                                            </td>

                                            <td>

                                                {mods.length > 0 ? (

                                                    <div className="vc-chips">

                                                        {mods.map((module) => (

                                                            <span
                                                                className="vc-chip"
                                                                key={module.CourseModule_id}
                                                            >
                                                                <i className="bx bx-check-circle"></i>
                                                                {module.CourseModule_name}
                                                            </span>

                                                        ))}

                                                    </div>

                                                ) : (

                                                    <span className="vc-empty">
                                                        No modules in this category.
                                                    </span>

                                                )}

                                            </td>

                                        </tr>

                                    );

                                })}

                            </tbody>

                        </table>

                    </div>


                    {/* FOOTER — STATS + CLOSE */}

                    <div className="vc-footer">

                        <div className="vc-stats">

                            <div className="vc-stat vc-stat-primary">
                                <div className="vc-stat-icon">
                                    <i className="bx bx-list-check"></i>
                                </div>
                                <div>
                                    <div className="vc-stat-label">
                                        Total Modules
                                    </div>
                                    <div className="vc-stat-value">
                                        {selectedIds.length}
                                    </div>
                                </div>
                            </div>

                            <div className="vc-stat vc-stat-info">
                                <div className="vc-stat-icon">
                                    <i className="bx bx-category"></i>
                                </div>
                                <div>
                                    <div className="vc-stat-label">
                                        Categories
                                    </div>
                                    <div className="vc-stat-value">
                                        {categoriesUsed}
                                    </div>
                                </div>
                            </div>

                        </div>

                        <button
                            type="button"
                            className="vc-close-btn"
                            onClick={props.toggle}
                        >
                            Close
                        </button>

                    </div>

                </div>

            </div>

        </div>

    );
};

export default Viewcourse;
