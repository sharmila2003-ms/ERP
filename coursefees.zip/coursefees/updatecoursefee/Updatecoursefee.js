import React, { useContext } from "react";
import AuthContext from "../../../services/AuthContext";

const Updatecoursefee = (props) => {

    const { update } = useContext(AuthContext);

    const courses = props.courses || [];

    const handleSubmit = async (e) => {

        e.preventDefault();

        const courseFeeData = {
            CourseFee_id: e.target.CourseFee_id.value,
            Course_id: parseInt(e.target.Course_id.value, 10),
            Course_Fees: parseFloat(e.target.Course_Fees.value),
            Duration: parseInt(e.target.Duration.value, 10),
            Duration_Type: e.target.Duration_Type.value,
            Status: e.target.Status.value
        };

        console.log(courseFeeData);

        try {

            await update(
                courseFeeData,
                "update_coursefee_datail",
                "/coursefees"
            );

            props.toggle();

        } catch (error) {

            console.error(
                "Update operation failed:",
                error
            );

        }
    };

    return (
        <div
            className="modal fade show"
            tabIndex="-1"
            role="dialog"
            style={{
                display: "block",
                backgroundColor: "rgba(0,0,0,0.5)"
            }}
        >

            <div
                className="modal-dialog modal-dialog-centered"
                role="document"
            >

                <div className="modal-content">

                    {/* =========================
                        HEADER
                    ========================== */}

                    <div className="modal-header">

                        <h5 className="modal-title">
                            Update Course Fee
                        </h5>

                        <button
                            type="button"
                            className="btn-close"
                            onClick={props.toggle}
                            aria-label="Close"
                        ></button>

                    </div>


                    {/* =========================
                        BODY
                    ========================== */}

                    <div className="modal-body">

                        <form onSubmit={handleSubmit}>

                            {/* Hidden Course Fee ID */}

                            <input
                                type="hidden"
                                name="CourseFee_id"
                                defaultValue={props.data.CourseFee_id}
                            />


                            {/* SELECT COURSE */}

                            <div className="mb-3">

                                <label
                                    htmlFor="Course_id"
                                    className="form-label"
                                >
                                    Select Course
                                </label>

                                <select
                                    id="Course_id"
                                    name="Course_id"
                                    className="form-select"
                                    defaultValue={props.data.Course_id}
                                    required
                                >

                                    <option value="" disabled>
                                        Select Course
                                    </option>

                                    {courses.map((course) => (

                                        <option
                                            key={course.Course_id}
                                            value={course.Course_id}
                                        >
                                            {course.Course_name}
                                        </option>

                                    ))}

                                </select>

                            </div>


                            {/* COURSE FEES */}

                            <div className="mb-3">

                                <label
                                    htmlFor="Course_Fees"
                                    className="form-label"
                                >
                                    Course Fees
                                </label>

                                <input
                                    type="number"
                                    defaultValue={props.data.Course_Fees}
                                    className="form-control"
                                    name="Course_Fees"
                                    id="Course_Fees"
                                    placeholder="e.g. 25000"
                                    min="0"
                                    step="0.01"
                                    required
                                />

                            </div>


                            {/* DURATION + DURATION TYPE */}

                            <div className="row">

                                <div className="col-6 mb-3">

                                    <label
                                        htmlFor="Duration"
                                        className="form-label"
                                    >
                                        Duration
                                    </label>

                                    <input
                                        type="number"
                                        defaultValue={props.data.Duration}
                                        className="form-control"
                                        id="Duration"
                                        name="Duration"
                                        placeholder="e.g. 4"
                                        min="1"
                                        step="1"
                                        required
                                    />

                                </div>


                                <div className="col-6 mb-3">

                                    <label
                                        htmlFor="Duration_Type"
                                        className="form-label"
                                    >
                                        Duration Type
                                    </label>

                                    <select
                                        id="Duration_Type"
                                        name="Duration_Type"
                                        className="form-select"
                                        defaultValue={props.data.Duration_Type}
                                        required
                                    >

                                        <option value="" disabled>
                                            Select Type
                                        </option>

                                        <option value="Days">
                                            Days
                                        </option>

                                        <option value="Months">
                                            Months
                                        </option>

                                        <option value="Years">
                                            Years
                                        </option>

                                    </select>

                                </div>

                            </div>


                            {/* STATUS */}

                            <div className="mb-3">

                                <label
                                    htmlFor="Status"
                                    className="form-label"
                                >
                                    Status
                                </label>

                                <select
                                    id="Status"
                                    name="Status"
                                    className="form-select"
                                    defaultValue={props.data.Status}
                                    required
                                >

                                    <option value="" disabled>
                                        Select Status
                                    </option>

                                    <option value="Active">
                                        Active
                                    </option>

                                    <option value="Inactive">
                                        Inactive
                                    </option>

                                </select>

                            </div>


                            {/* =========================
                                FOOTER
                            ========================== */}

                            <div className="modal-footer px-0 pb-0">

                                <button
                                    type="button"
                                    className="btn btn-outline-secondary"
                                    onClick={props.toggle}
                                >
                                    Cancel
                                </button>

                                <button
                                    type="submit"
                                    className="btn btn-success"
                                >
                                    Update Course Fee
                                </button>

                            </div>

                        </form>

                    </div>

                </div>

            </div>

        </div>
    );
};

export default Updatecoursefee;
