import React, {
    useState,
    useContext,
    useEffect,
    useCallback
} from "react";

import "./CourseFee.css";

import Addcoursefee from "./addcoursefee/Addcoursefee";
import Updatecoursefee from "./updatecoursefee/Updatecoursefee";
import Deletecoursefee from "./deletecoursefee/Deletecoursefee";

import AuthContext from "../../services/AuthContext";


function CourseFee() {

    const [addPopupVisible, setAddPopupVisible] = useState(false);
    const [updatePopupVisible, setUpdatePopupVisible] = useState(false);
    const [deletePopupVisible, setDeletePopupVisible] = useState(false);

    const [currentPage, setCurrentPage] = useState(1);

    const { getData } = useContext(AuthContext);

    const [courseFees, setCourseFees] = useState([]);

    const [courses, setCourses] = useState([]);

    const [value, setValue] = useState(null);


    // =====================================================
    // FETCH COURSE FEES
    // =====================================================

    const fetchCourseFees = useCallback(async () => {

        try {

            const data = await getData(
                "fetch_coursefee_datail"
            );

            console.log(
                "Course Fees fetched:",
                data
            );

            if (Array.isArray(data)) {

                setCourseFees(data);

            } else {

                setCourseFees([]);

            }

        } catch (err) {

            console.error(
                "Failed to fetch course fees:",
                err
            );

        }

    }, [getData]);


    // =====================================================
    // FETCH COURSES (for dropdown + name lookup)
    // =====================================================

    const fetchCourses = useCallback(async () => {

        try {

            const data = await getData(
                "fetch_course_datail"
            );

            if (Array.isArray(data)) {

                setCourses(data);

            } else {

                setCourses([]);

            }

        } catch (err) {

            console.error(
                "Failed to fetch courses:",
                err
            );

        }

    }, [getData]);


    // =====================================================
    // INITIAL LOAD
    // =====================================================

    useEffect(() => {

        fetchCourseFees();

        fetchCourses();

    }, [fetchCourseFees, fetchCourses]);


    // =====================================================
    // ADD POPUP
    // =====================================================

    const toggleAddPopup = () => {

        setAddPopupVisible(
            !addPopupVisible
        );

    };


    // =====================================================
    // UPDATE POPUP
    // =====================================================

    const toggleUpdatePopup = () => {

        setUpdatePopupVisible(
            !updatePopupVisible
        );

    };


    // =====================================================
    // DELETE POPUP
    // =====================================================

    const toggleDeletePopup = () => {

        setDeletePopupVisible(
            !deletePopupVisible
        );

    };


    // =====================================================
    // AFTER COURSE FEE CREATED
    // =====================================================

    const handleCourseFeeCreated = async () => {

        console.log(
            "New course fee created. Refreshing list..."
        );

        // Fetch latest data from Django
        await fetchCourseFees();

        // Close popup
        setAddPopupVisible(false);

        // Go back to first page
        setCurrentPage(1);

    };


    // =====================================================
    // PAGINATION
    // =====================================================

    const itemsPerPage = 4;

    const indexOfLastItem =
        currentPage * itemsPerPage;

    const indexOfFirstItem =
        indexOfLastItem - itemsPerPage;

    const currentCourseFees =
        courseFees.slice(
            indexOfFirstItem,
            indexOfLastItem
        );


    const nextPage = () => {

        if (
            indexOfLastItem <
            courseFees.length
        ) {

            setCurrentPage(
                currentPage + 1
            );

        }

    };


    const prevPage = () => {

        if (currentPage > 1) {

            setCurrentPage(
                currentPage - 1
            );

        }

    };


    // =====================================================
    // UPDATE
    // =====================================================

    const handleUpdate = (courseFee) => {

        setValue(courseFee);

        toggleUpdatePopup();

    };


    // =====================================================
    // DELETE
    // =====================================================

    const handleDelete = (id) => {

        setValue(id);

        toggleDeletePopup();

    };


    // =====================================================
    // HELPER: RESOLVE COURSE NAME
    // =====================================================

    const getCourseName = (courseFee) => {

        const match = courses.find(
            (c) => c.Course_id === courseFee.Course_id
        );

        return match
            ? match.Course_name
            : courseFee.Course_id;

    };


    return (

        <div className="coursefee-page container-xxl flex-grow-1 container-p-y">


            {/* ================================================= */}
            {/* HEADER */}
            {/* ================================================= */}

            <div className="page-header">

                <div>

                    <h3 className="page-title">
                        Course Fee Management
                    </h3>

                    <p className="page-subtitle">
                        Manage fees and duration plans for each course
                    </p>

                </div>


                <button
                    className="btn btn-primary add-btn"
                    onClick={toggleAddPopup}
                >

                    <i className="bx bx-plus me-2"></i>

                    Add Course Fee

                </button>

            </div>


            {/* ================================================= */}
            {/* ADD COURSE FEE POPUP */}
            {/* ================================================= */}

            {addPopupVisible && (

                <Addcoursefee
                    toggle={toggleAddPopup}
                    onSuccess={handleCourseFeeCreated}
                    courses={courses}
                />

            )}


            {/* ================================================= */}
            {/* COURSE FEE TABLE */}
            {/* ================================================= */}

            <div className="card coursefee-card">

                <div className="table-responsive">

                    <table className="table modern-table">

                        <thead>

                            <tr>

                                <th>ID</th>

                                <th>
                                    Course
                                </th>

                                <th>
                                    Course Fees
                                </th>

                                <th>
                                    Duration
                                </th>

                                <th>
                                    Status
                                </th>

                                <th width="180">
                                    Action
                                </th>

                            </tr>

                        </thead>


                        <tbody>

                            {currentCourseFees.length > 0 ? (

                                currentCourseFees.map(
                                    (courseFee) => (

                                        <tr
                                            key={
                                                courseFee.CourseFee_id
                                            }
                                        >

                                            <td>
                                                #{courseFee.CourseFee_id}
                                            </td>


                                            <td>

                                                <strong>
                                                    {
                                                        getCourseName(courseFee)
                                                    }
                                                </strong>

                                            </td>


                                            <td>

                                                {
                                                    courseFee.Course_Fees
                                                }

                                            </td>


                                            <td>

                                                {
                                                    courseFee.Duration
                                                }{" "}
                                                {
                                                    courseFee.Duration_Type
                                                }

                                            </td>


                                            <td>

                                                <span
                                                    className={
                                                        courseFee.Status ===
                                                        "Active"
                                                            ? "status active"
                                                            : "status inactive"
                                                    }
                                                >

                                                    {
                                                        courseFee.Status
                                                    }

                                                </span>

                                            </td>


                                            <td>

                                                <div className="action-buttons">

                                                    <button
                                                        className="btn btn-edit"
                                                        onClick={() =>
                                                            handleUpdate(
                                                                courseFee
                                                            )
                                                        }
                                                    >
                                                        Edit
                                                    </button>


                                                    <button
                                                        className="btn btn-delete"
                                                        onClick={() =>
                                                            handleDelete(
                                                                courseFee.CourseFee_id
                                                            )
                                                        }
                                                    >
                                                        Delete
                                                    </button>

                                                </div>

                                            </td>

                                        </tr>

                                    )
                                )

                            ) : (

                                <tr>

                                    <td
                                        colSpan="6"
                                        className="text-center py-4"
                                    >

                                        No course fee plans found.

                                    </td>

                                </tr>

                            )}

                        </tbody>

                    </table>

                </div>


                {/* ================================================= */}
                {/* UPDATE */}
                {/* ================================================= */}

                {updatePopupVisible && (

                    <Updatecoursefee
                        toggle={toggleUpdatePopup}
                        data={value}
                        courses={courses}
                    />

                )}


                {/* ================================================= */}
                {/* DELETE */}
                {/* ================================================= */}

                {deletePopupVisible && (

                    <Deletecoursefee
                        toggle={toggleDeletePopup}
                        data={value}
                    />

                )}


                {/* ================================================= */}
                {/* PAGINATION */}
                {/* ================================================= */}

                <div className="card-footer bg-white border-0">

                    <div className="d-flex justify-content-end">

                        <button
                            className="btn btn-light me-2"
                            onClick={prevPage}
                            disabled={
                                currentPage === 1
                            }
                        >

                            <i className="bx bx-chevron-left"></i>

                            Previous

                        </button>


                        <button
                            className="btn btn-primary"
                            onClick={nextPage}
                            disabled={
                                indexOfLastItem >=
                                courseFees.length
                            }
                        >

                            Next

                            <i className="bx bx-chevron-right ms-1"></i>

                        </button>

                    </div>

                </div>

            </div>

        </div>

    );

}


export default CourseFee;
