import React, { useContext, useState } from "react";
import AuthContext from "../../../services/AuthContext";
// import "./addcoursefee.css";

const Addcoursefee = (props) => {

    const { insert } = useContext(AuthContext);

    const [validated, setValidated] = useState(false);
    const [error, setError] = useState("");
    const [success, setSuccess] = useState("");
    const [loading, setLoading] = useState(false);

    const courses = props.courses || [];


    const handleSubmit = async (e) => {

        e.preventDefault();

        const form = e.currentTarget;

        setError("");
        setSuccess("");


        // =========================
        // FORM VALIDATION
        // =========================

        if (!form.checkValidity()) {

            e.stopPropagation();

            setValidated(true);

            return;
        }


        // =========================
        // GET FORM DATA
        // =========================

        const courseId =
            form.Course_id.value;

        const courseFees =
            form.Course_Fees.value;

        const duration =
            form.Duration.value;

        const durationType =
            form.Duration_Type.value;

        const status =
            form.Status.value;


        // =========================
        // COURSE FEE DATA
        // =========================

        const courseFeeData = {

            Course_id: parseInt(courseId, 10),

            Course_Fees: parseFloat(courseFees),

            Duration: parseInt(duration, 10),

            Duration_Type: durationType,

            Status: status,

        };


        console.log(
            "Sending Course Fee:",
            courseFeeData
        );


        try {

            setLoading(true);


            // =========================
            // INSERT
            // =========================

            const response = await insert(
                courseFeeData,
                "coursefee_create"
            );


            console.log(
                "Course Fee created:",
                response
            );


            // =========================
            // SUCCESS
            // =========================

            setSuccess(
    "Course fee plan created successfully!"
);


// Clear form
form.reset();

setValidated(false);


// Refresh parent list
if (props.onSuccess) {

    await props.onSuccess();

}


        } catch (error) {

            console.error(
                "Course fee creation error:",
                error
            );


            // =========================
            // DJANGO ERROR
            // =========================

            const responseData =
                error.responseData;


            console.log(
                "Django Error:",
                responseData
            );


            // Detail error
            if (
                responseData &&
                responseData.detail
            ) {

                setError(
                    responseData.detail
                );

            }

            // Other server error
            else {

                setError(
                    "Course fee plan could not be created. Please try again."
                );
            }

        } finally {

            setLoading(false);

        }

    };


return (
    <div
        className="modal fade show"
        tabIndex="-1"
        role="dialog"
        style={{ display: "block", backgroundColor: "rgba(0,0,0,0.5)" }}
    >
        <div
            className="modal-dialog modal-dialog-centered"
            role="document"
        >
            <div className="modal-content">

                {/* HEADER */}
                <div className="modal-header">

                    <h5 className="modal-title">
                        Add Course Fee
                    </h5>

                    <button
                        type="button"
                        className="btn-close"
                        onClick={props.toggle}
                        aria-label="Close"
                    ></button>

                </div>

                {/* BODY */}
                <div className="modal-body">

                    {/* SUCCESS */}
                    {success && (
                        <div
                            className="alert alert-success"
                            role="alert"
                        >
                            <strong>Success!</strong>{" "}
                            {success}
                        </div>
                    )}

                    {/* ERROR */}
                    {error && (
                        <div
                            className="alert alert-danger"
                            role="alert"
                        >
                            <strong>Error!</strong>{" "}
                            {error}
                        </div>
                    )}

                    <form
                        onSubmit={handleSubmit}
                        noValidate
                        className={
                            validated ? "was-validated" : ""
                        }
                    >

                        {/* SELECT COURSE */}
                        <div className="mb-3">

                            <label
                                htmlFor="Course_id"
                                className="form-label"
                            >
                                Select Course
                            </label>

                            <select
                                id="Course_id"
                                name="Course_id"
                                className="form-select"
                                required
                                defaultValue=""
                            >

                                <option value="" disabled>
                                    Select Course
                                </option>

                                {courses.map((course) => (

                                    <option
                                        key={course.Course_id}
                                        value={course.Course_id}
                                    >
                                        {course.Course_name}
                                    </option>

                                ))}

                            </select>

                            <div className="invalid-feedback">
                                Please select a course.
                            </div>

                        </div>


                        {/* COURSE FEES */}
                        <div className="mb-3">

                            <label
                                htmlFor="Course_Fees"
                                className="form-label"
                            >
                                Course Fees
                            </label>

                            <input
                                type="number"
                                name="Course_Fees"
                                id="Course_Fees"
                                className="form-control"
                                placeholder="e.g. 25000"
                                required
                                min="0"
                                step="0.01"
                            />

                            <div className="invalid-feedback">
                                Please enter a valid fee amount.
                            </div>

                        </div>


                        {/* DURATION + DURATION TYPE */}
                        <div className="row">

                            <div className="col-6 mb-3">

                                <label
                                    htmlFor="Duration"
                                    className="form-label"
                                >
                                    Duration
                                </label>

                                <input
                                    type="number"
                                    name="Duration"
                                    id="Duration"
                                    className="form-control"
                                    placeholder="e.g. 4"
                                    required
                                    min="1"
                                    step="1"
                                />

                                <div className="invalid-feedback">
                                    Please enter a valid duration.
                                </div>

                            </div>


                            <div className="col-6 mb-3">

                                <label
                                    htmlFor="Duration_Type"
                                    className="form-label"
                                >
                                    Duration Type
                                </label>

                                <select
                                    id="Duration_Type"
                                    name="Duration_Type"
                                    className="form-select"
                                    required
                                    defaultValue=""
                                >

                                    <option value="" disabled>
                                        Select Type
                                    </option>

                                    <option value="Days">
                                        Days
                                    </option>

                                    <option value="Months">
                                        Months
                                    </option>

                                    <option value="Years">
                                        Years
                                    </option>

                                </select>

                                <div className="invalid-feedback">
                                    Please select a duration type.
                                </div>

                            </div>

                        </div>


                        {/* STATUS */}
                        <div className="mb-3">

                            <label
                                htmlFor="Status"
                                className="form-label"
                            >
                                Status
                            </label>

                            <select
                                id="Status"
                                name="Status"
                                className="form-select"
                                required
                                defaultValue=""
                            >

                                <option value="" disabled>
                                    Select Status
                                </option>

                                <option value="Active">
                                    Active
                                </option>

                                <option value="Inactive">
                                    Inactive
                                </option>

                            </select>

                            <div className="invalid-feedback">
                                Please select status.
                            </div>

                        </div>

                        {/* FOOTER BUTTONS */}
                        <div className="modal-footer px-0 pb-0">

                            <button
                                type="button"
                                className="btn btn-outline-secondary"
                                onClick={props.toggle}
                                disabled={loading}
                            >
                                Cancel
                            </button>

                            <button
                                type="submit"
                                className="btn btn-primary"
                                disabled={loading}
                            >

                                {loading ? (
                                    <>
                                        <span
                                            className="spinner-border spinner-border-sm me-2"
                                            role="status"
                                            aria-hidden="true"
                                        ></span>

                                        Saving...
                                    </>
                                ) : (
                                    "Save"
                                )}

                            </button>

                        </div>

                    </form>

                </div>

            </div>
        </div>
    </div>
);
};


export default Addcoursefee;
