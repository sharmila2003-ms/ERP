import React, { useContext, useState } from "react";
import AuthContext from "../../../services/AuthContext";
import "../addcoursemodule/addcoursemodule.css";

const Deletecoursemodule = (props) => {

    const { Delete } = useContext(AuthContext);

    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);

    // props.data is the whole course module object
    const courseModule = props.data || {};

    const topicCount = Array.isArray(courseModule.CourseModule_Syllabus)
        ? courseModule.CourseModule_Syllabus.length
        : 0;


    const handleSubmit = async () => {

        setError("");

        try {

            if (!courseModule.CourseModule_id) {

                throw new Error(
                    "Missing or invalid data for deletion"
                );

            }

            setLoading(true);

            await Delete(
                { CourseModule_id: courseModule.CourseModule_id },
                "delete_coursemodule_datail",
                "/coursemodule"
            );

            // Refresh the list and go back to it
            if (props.onSuccess) {

                await props.onSuccess();

            } else {

                props.toggle();

            }

        } catch (error) {

            console.error(
                "Delete operation failed:",
                error
            );

            setError(
                "Course Module could not be deleted. Please try again."
            );

        } finally {

            setLoading(false);

        }
    };


    return (

        <div className="coursemodule-page centered-form-page container-xxl flex-grow-1 container-p-y">

            <div className="centered-form-wrap">


                {/* ================================================= */}
                {/* HEADER */}
                {/* ================================================= */}

                <div className="page-header">

                    <div>

                        <h3 className="page-title">
                            Delete Course Module
                        </h3>

                        <p className="page-subtitle">
                            Please confirm before deleting
                        </p>

                    </div>


                    <button
                        type="button"
                        className="btn btn-outline-secondary add-btn"
                        onClick={props.toggle}
                        disabled={loading}
                    >

                        <i className="bx bx-arrow-back me-2"></i>

                        Back to List

                    </button>

                </div>


                {/* ================================================= */}
                {/* CONFIRM CARD */}
                {/* ================================================= */}

                <div className="card coursemodule-card">

                    <div className="card-body text-center">

                        {/* ERROR */}
                        {error && (
                            <div
                                className="alert alert-danger text-start"
                                role="alert"
                            >
                                <strong>Error!</strong>{" "}
                                {error}
                            </div>
                        )}

                        <div
                            className="text-danger mb-3"
                            style={{ fontSize: "40px" }}
                        >
                            ⚠
                        </div>

                        <h5>
                            Are you sure you want to delete
                            {courseModule.CourseModule_name
                                ? ` "${courseModule.CourseModule_name}"`
                                : " this course module"}
                            ?
                        </h5>

                        <p className="text-muted mb-0">
                            {topicCount > 0
                                ? `Its ${topicCount} syllabus topic${topicCount === 1 ? "" : "s"} will be deleted too. `
                                : ""}
                            This action cannot be undone.
                        </p>


                        <div className="d-flex justify-content-center gap-2 mt-4">

                            <button
                                type="button"
                                className="btn btn-outline-secondary"
                                onClick={props.toggle}
                                disabled={loading}
                            >
                                Cancel
                            </button>

                            <button
                                type="button"
                                onClick={handleSubmit}
                                className="btn btn-danger"
                                disabled={loading}
                            >

                                {loading ? (
                                    <>
                                        <span
                                            className="spinner-border spinner-border-sm me-2"
                                            role="status"
                                            aria-hidden="true"
                                        ></span>

                                        Deleting...
                                    </>
                                ) : (
                                    "Delete"
                                )}

                            </button>

                        </div>

                    </div>

                </div>

            </div>

        </div>
    );
};

export default Deletecoursemodule;
