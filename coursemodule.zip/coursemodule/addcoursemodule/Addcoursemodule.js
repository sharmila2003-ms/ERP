import React, { useContext, useState } from "react";
import AuthContext from "../../../services/AuthContext";
import "./addcoursemodule.css";
import KeywordInput, { CATEGORY_KEYWORDS } from "../KeywordInput";

const Addcoursemodule = (props) => {

    const { insert } = useContext(AuthContext);

    const [validated, setValidated] = useState(false);
    const [error, setError] = useState("");
    const [success, setSuccess] = useState("");
    const [loading, setLoading] = useState(false);
    const [description, setDescription] = useState("");

    // =====================================================
    // SYLLABUS TOPICS (dynamic Topic / Duration rows)
    // =====================================================

    const [topics, setTopics] = useState([
        { topic: "", duration: "" }
    ]);


    const addTopicRow = () => {

        setTopics((prev) => [
            ...prev,
            { topic: "", duration: "" }
        ]);

    };


    const insertTopicRowAfter = (index) => {

        setTopics((prev) => {

            const updated = [...prev];

            updated.splice(index + 1, 0, { topic: "", duration: "" });

            return updated;

        });

    };


    const removeTopicRow = (index) => {

        setTopics((prev) =>
            prev.filter((_, i) => i !== index)
        );

    };


    const updateTopicField = (index, field, fieldValue) => {

        setTopics((prev) =>
            prev.map((row, i) =>
                i === index
                    ? { ...row, [field]: fieldValue }
                    : row
            )
        );

    };


    // =====================================================
    // SMART PASTE: pasting multi-line text into a Topic cell
    // instantly splits it into one row per line, starting at
    // the row that was pasted into.
    // =====================================================

    const handleTopicPaste = (e, index) => {

        const pastedText = e.clipboardData.getData("text");

        const lines = pastedText
            .split(/\r?\n/)
            .map((line) => line.trim())
            .filter((line) => line !== "");

        // Single line (or empty) — let the normal paste happen.
        if (lines.length <= 1) {

            return;

        }

        // Multi-line paste — take over and spread it across rows.
        e.preventDefault();

        setTopics((prev) => {

            const updated = [...prev];

            // First pasted line fills the row that was pasted into.
            updated[index] = {
                ...updated[index],
                topic: lines[0]
            };

            // Remaining lines become new rows, inserted right after it.
            const newRows = lines.slice(1).map((line) => ({
                topic: line,
                duration: ""
            }));

            updated.splice(index + 1, 0, ...newRows);

            return updated;

        });

    };


    const handleSubmit = async (e) => {

        e.preventDefault();

        const form = e.currentTarget;

        setError("");
        setSuccess("");


        // =========================
        // FORM VALIDATION
        // =========================

        if (!form.checkValidity()) {

            e.stopPropagation();

            setValidated(true);

            return;
        }


        // =========================
        // GET FORM DATA
        // =========================

        const moduleName =
            form.CourseModule_name.value.trim();

        // read from state: the form has a hidden field for this value,
        // and looking it up through the form object is unreliable
        const moduleDescription = description.trim();


        // =========================
        // MODULE NAME VALIDATION
        // =========================

        if (moduleName.length < 2) {

            setError(
                "Module name must contain at least 2 characters."
            );

            setValidated(true);

            return;
        }


        // =========================
        // DESCRIPTION KEYWORD VALIDATION
        // =========================

        const matchedKeyword = CATEGORY_KEYWORDS.find(
            (k) => k.toLowerCase() === moduleDescription.toLowerCase()
        );

        if (!matchedKeyword) {

            setError(
                "Please choose a category: Frontend, Database, Backend or Others."
            );

            setValidated(true);

            return;
        }


        // =========================
        // SYLLABUS TOPICS VALIDATION
        // =========================

        const cleanedTopics = topics
            .map((row) => ({
                topic: row.topic.trim(),
                duration: row.duration.trim()
            }))
            .filter((row) => row.topic !== "");

        if (cleanedTopics.length === 0) {

            setError(
                "Please add at least one syllabus topic."
            );

            return;
        }


        // =========================
        // COURSE MODULE DATA
        // =========================

        const courseModuleData = {

            CourseModule_name: moduleName,

            CourseModule_category: matchedKeyword,

            // Status is no longer asked for here — new modules
            // are created Active by default.
            CourseModule_Status: "Active",

            // Array of { topic, duration } rows
            CourseModule_Syllabus: cleanedTopics,

        };


        console.log(
            "Sending Course Module:",
            courseModuleData
        );


        try {

            setLoading(true);


            // =========================
            // INSERT
            // =========================

            const response = await insert(
                courseModuleData,
                "coursemodule_create"
            );


            console.log(
                "Course Module created:",
                response
            );


            // =========================
            // SUCCESS
            // =========================

            setSuccess(
    "Course Module created successfully!"
);


// Clear form
form.reset();

setDescription("");

setTopics([{ topic: "", duration: "" }]);

setValidated(false);


// Refresh parent course module list
if (props.onSuccess) {

    await props.onSuccess();

}


        } catch (error) {

            console.error(
                "Course Module creation error:",
                error
            );


            // =========================
            // DJANGO ERROR
            // =========================

            const responseData =
                error.responseData;


            console.log(
                "Django Error:",
                responseData
            );


            // Module name duplicate
            if (
                responseData &&
                responseData.CourseModule_name
            ) {

                const message =
                    Array.isArray(
                        responseData.CourseModule_name
                    )
                        ? responseData.CourseModule_name[0]
                        : responseData.CourseModule_name;


                setError(message);

            }

            // Detail error
            else if (
                responseData &&
                responseData.detail
            ) {

                setError(
                    responseData.detail
                );

            }

            // Other server error
            else {

                setError(
                    "Course Module could not be created. Please try again."
                );
            }

        } finally {

            setLoading(false);

        }

    };


return (

    <div className="coursemodule-page centered-form-page container-xxl flex-grow-1 container-p-y">

        <div className="centered-form-wrap">


            {/* ================================================= */}
            {/* HEADER */}
            {/* ================================================= */}

            <div className="page-header">

                <div>

                    <h3 className="page-title">
                        Add Course Module
                    </h3>

                    <p className="page-subtitle">
                        Create a new course module
                    </p>

                </div>


                <button
                    type="button"
                    className="btn btn-outline-secondary add-btn"
                    onClick={props.toggle}
                >

                    <i className="bx bx-arrow-back me-2"></i>

                    Back to List

                </button>

            </div>


            {/* ================================================= */}
            {/* FORM CARD */}
            {/* ================================================= */}

            <div className="card coursemodule-card">

                <div className="card-body">

                    {/* SUCCESS */}
                    {success && (
                        <div
                            className="alert alert-success"
                            role="alert"
                        >
                            <strong>Success!</strong>{" "}
                            {success}
                        </div>
                    )}

                    {/* ERROR */}
                    {error && (
                        <div
                            className="alert alert-danger"
                            role="alert"
                        >
                            <strong>Error!</strong>{" "}
                            {error}
                        </div>
                    )}

                    <form
                        onSubmit={handleSubmit}
                        noValidate
                        className={
                            validated ? "was-validated" : ""
                        }
                    >

                        {/* MODULE NAME + DESCRIPTION — one row, two columns */}
                        <div className="row">

                            <div className="col-md-6 mb-3">

                                <label
                                    htmlFor="CourseModule_name"
                                    className="form-label"
                                >
                                    Module Name
                                </label>

                                <input
                                    type="text"
                                    name="CourseModule_name"
                                    id="CourseModule_name"
                                    className="form-control"
                                    placeholder="e.g. HTML"
                                    required
                                    minLength="2"
                                    maxLength="255"
                                />

                                <div className="invalid-feedback">
                                    Please enter a valid module name.
                                </div>

                            </div>


                            <div className="col-md-6 mb-3">

                                <label
                                    htmlFor="CourseModule_category_text"
                                    className="form-label"
                                >
                                    Category
                                </label>

                                <KeywordInput
                                    value={description}
                                    onChange={setDescription}
                                />

                                <div className="invalid-feedback">
                                    Please type and choose Frontend, Database, Backend or Others.
                                </div>

                            </div>

                        </div>


                        {/* SYLLABUS / DURATION — dynamic topic rows */}
                        <div className="mb-3">

                            <label className="form-label">
                                Syllabus
                            </label>

                            <div className="syllabus-table-wrap">

                                <table className="syllabus-table">

                                    <thead>

                                        <tr>

                                            <th className="syllabus-no-col">
                                                No
                                            </th>

                                            <th>
                                                Topic
                                            </th>

                                            <th className="syllabus-duration-col">
                                                Duration
                                            </th>

                                            <th className="syllabus-action-col"></th>

                                        </tr>

                                    </thead>


                                    <tbody>

                                        {topics.map((row, index) => (

                                            <tr key={index}>

                                                <td>
                                                    {index + 1}
                                                </td>

                                                <td>

                                                    <input
                                                        type="text"
                                                        className="form-control form-control-sm"
                                                        placeholder="e.g. Introduction to HTML"
                                                        maxLength="255"
                                                        value={row.topic}
                                                        onChange={(e) =>
                                                            updateTopicField(
                                                                index,
                                                                "topic",
                                                                e.target.value
                                                            )
                                                        }
                                                        onPaste={(e) =>
                                                            handleTopicPaste(
                                                                e,
                                                                index
                                                            )
                                                        }
                                                    />

                                                </td>

                                                <td>

                                                    <input
                                                        type="text"
                                                        className="form-control form-control-sm"
                                                        placeholder="e.g. 1 Hr"
                                                        maxLength="50"
                                                        value={row.duration}
                                                        onChange={(e) =>
                                                            updateTopicField(
                                                                index,
                                                                "duration",
                                                                e.target.value
                                                            )
                                                        }
                                                    />

                                                </td>

                                                <td>

                                                    <div className="syllabus-actions">

                                                        <button
                                                            type="button"
                                                            className="syllabus-icon-btn syllabus-icon-add"
                                                            onClick={() =>
                                                                insertTopicRowAfter(index)
                                                            }
                                                            title="Add topic below"
                                                        >
                                                            <i className="bx bx-plus"></i>
                                                        </button>

                                                        <button
                                                            type="button"
                                                            className="syllabus-icon-btn syllabus-icon-remove"
                                                            onClick={() =>
                                                                removeTopicRow(index)
                                                            }
                                                            disabled={topics.length === 1}
                                                            title="Remove topic"
                                                        >
                                                            <i className="bx bx-minus"></i>
                                                        </button>

                                                    </div>

                                                </td>

                                            </tr>

                                        ))}

                                    </tbody>

                                </table>

                                <button
                                    type="button"
                                    className="syllabus-add-btn"
                                    onClick={addTopicRow}
                                >
                                    + Add Syllabus Topic
                                </button>

                            </div>

                        </div>

                        {/* FOOTER BUTTONS */}
                        <div className="d-flex justify-content-end gap-2 mt-4">

                            <button
                                type="button"
                                className="btn btn-outline-secondary"
                                onClick={props.toggle}
                                disabled={loading}
                            >
                                Cancel
                            </button>

                            <button
                                type="submit"
                                className="btn btn-primary"
                                disabled={loading}
                            >

                                {loading ? (
                                    <>
                                        <span
                                            className="spinner-border spinner-border-sm me-2"
                                            role="status"
                                            aria-hidden="true"
                                        ></span>

                                        Saving...
                                    </>
                                ) : (
                                    "Save Course Module"
                                )}

                            </button>

                        </div>

                    </form>

                </div>

            </div>

        </div>

    </div>

);
};


export default Addcoursemodule;
