import React, {
    useState,
    useContext,
    useEffect,
    useCallback
} from "react";

import "./CourseModule.css";

import Addcoursemodule from "./addcoursemodule/Addcoursemodule";
import Updatecoursemodule from "./updatecoursemodule/Updatecoursemodule";
import Deletecoursemodule from "./deletecoursemodule/Deletecoursemodule";

import AuthContext from "../../services/AuthContext";


function CourseModule() {

    const [addPopupVisible, setAddPopupVisible] = useState(false);
    const [updatePageVisible, setUpdatePageVisible] = useState(false);
    const [deletePageVisible, setDeletePageVisible] = useState(false);

    // Module whose syllabus is open in the View modal (null = closed)
    const [syllabusModule, setSyllabusModule] = useState(null);

    const [currentPage, setCurrentPage] = useState(1);

    const { getData, update } = useContext(AuthContext);

    const [courseModules, setCourseModules] = useState([]);

    const [value, setValue] = useState(null);


    // =====================================================
    // FETCH COURSE MODULES
    // =====================================================

    const fetchCourseModules = useCallback(async () => {

        try {

            const data = await getData(
                "fetch_coursemodule_datail"
            );

            console.log(
                "Course Modules fetched:",
                data
            );

            if (Array.isArray(data)) {

                setCourseModules(data);

            } else {

                setCourseModules([]);

            }

        } catch (err) {

            console.error(
                "Failed to fetch course modules:",
                err
            );

        }

    }, [getData]);


    // =====================================================
    // INITIAL LOAD
    // =====================================================

    useEffect(() => {

        fetchCourseModules();

    }, [fetchCourseModules]);


    // =====================================================
    // ADD PAGE (no longer a popup — swaps the table view
    // for the Addcoursemodule page directly, centered)
    // =====================================================

    const showAddPage = () => {

        setAddPopupVisible(true);

    };

    const hideAddPage = () => {

        setAddPopupVisible(false);

    };


    // =====================================================
    // EDIT PAGE (no longer a popup — swaps the list for the
    // Updatecoursemodule page directly, like the Add page)
    // =====================================================

    const hideUpdatePage = () => {

        setUpdatePageVisible(false);

    };


    const handleCourseModuleUpdated = async () => {

        // Fetch latest data from Django, then back to the list
        // (stay on the same pagination page)
        await fetchCourseModules();

        setUpdatePageVisible(false);

    };


    // =====================================================
    // DELETE PAGE (no longer a popup — confirmation page)
    // =====================================================

    const hideDeletePage = () => {

        setDeletePageVisible(false);

    };


    const handleCourseModuleDeleted = async () => {

        await fetchCourseModules();

        setDeletePageVisible(false);

        // The current page may no longer exist after a delete
        setCurrentPage(1);

    };


    // =====================================================
    // AFTER COURSE MODULE CREATED
    // =====================================================

    const handleCourseModuleCreated = async () => {

        console.log(
            "New course module created. Refreshing list..."
        );

        // Fetch latest data from Django
        await fetchCourseModules();

        // Close add page, back to list
        setAddPopupVisible(false);

        // Go back to first page
        setCurrentPage(1);

    };


    // =====================================================
    // PAGINATION
    // =====================================================

    const itemsPerPage = 4;

    const indexOfLastItem =
        currentPage * itemsPerPage;

    const indexOfFirstItem =
        indexOfLastItem - itemsPerPage;

    const currentCourseModules =
        courseModules.slice(
            indexOfFirstItem,
            indexOfLastItem
        );


    const nextPage = () => {

        if (
            indexOfLastItem <
            courseModules.length
        ) {

            setCurrentPage(
                currentPage + 1
            );

        }

    };


    const prevPage = () => {

        if (currentPage > 1) {

            setCurrentPage(
                currentPage - 1
            );

        }

    };


    // =====================================================
    // UPDATE
    // =====================================================

    const handleUpdate = (courseModule) => {

        setValue(courseModule);

        setUpdatePageVisible(true);

    };


    // =====================================================
    // DELETE
    // =====================================================

    const handleDelete = (courseModule) => {

        setValue(courseModule);

        setDeletePageVisible(true);

    };


    // =====================================================
    // STATUS BUTTON (Active / Deactive — click to switch)
    // =====================================================

    const handleToggleStatus = async (courseModule) => {

        const newStatus =
            courseModule.CourseModule_Status === "Active"
                ? "Deactive"
                : "Active";

        const payload = {
            CourseModule_id: courseModule.CourseModule_id,
            CourseModule_name: courseModule.CourseModule_name,
            CourseModule_category: courseModule.CourseModule_category,
            CourseModule_Syllabus: courseModule.CourseModule_Syllabus,
            CourseModule_Status: newStatus,
        };

        try {

            await update(
                payload,
                "update_coursemodule_datail",
                "/coursemodule"
            );

            await fetchCourseModules();

        } catch (err) {

            console.error(
                "Failed to toggle status:",
                err
            );

        }

    };


    // =====================================================
    // TOTAL DURATION (sum of every syllabus topic's duration)
    // Durations are typed as free text, e.g. "1 Hr", "30 min",
    // "1h 30m", "2.5 hours". A number with no unit is read as
    // hours. Topics whose duration can't be read are skipped.
    // =====================================================

    const getTotalMinutes = (courseModule) => {

        const topics = courseModule.CourseModule_Syllabus;

        if (!Array.isArray(topics)) {

            return 0;

        }

        let totalMinutes = 0;

        topics.forEach((row) => {

            const text = String(row.duration || "").toLowerCase();

            const parts = [
                ...text.matchAll(
                    /(\d+(?:\.\d+)?)\s*(hours?|hrs?|h|minutes?|mins?|m)?/g
                )
            ];

            parts.forEach((match) => {

                const amount = parseFloat(match[1]);

                const unit = match[2] || "h";

                totalMinutes += unit.startsWith("m")
                    ? amount
                    : amount * 60;

            });

        });

        return Math.round(totalMinutes);

    };


    // 150 -> "2 Hrs 30 Mins", 60 -> "1 Hr", 0 -> "-"
    const formatDuration = (totalMinutes) => {

        if (totalMinutes === 0) {

            return "-";

        }

        const hours = Math.floor(totalMinutes / 60);

        const minutes = totalMinutes % 60;

        const hourText = `${hours} ${hours === 1 ? "Hr" : "Hrs"}`;

        const minuteText = `${minutes} ${minutes === 1 ? "Min" : "Mins"}`;

        if (hours > 0 && minutes > 0) {

            return `${hourText} ${minuteText}`;

        }

        return hours > 0 ? hourText : minuteText;

    };


    const getTotalDuration = (courseModule) =>
        formatDuration(getTotalMinutes(courseModule));


    // A bare number ("1", "2.5") is read as hours everywhere else,
    // so show it that way here too: "1" -> "1 Hr", "2" -> "2 Hrs".
    const formatTopicDuration = (text) => {

        const value = String(text || "").trim();

        if (value === "") {

            return "-";

        }

        if (/^\d+(\.\d+)?$/.test(value)) {

            return `${value} ${parseFloat(value) === 1 ? "Hr" : "Hrs"}`;

        }

        return value;

    };


    // =====================================================
    // SYLLABUS VIEW MODAL
    // =====================================================

    const openSyllabus = (courseModule) => {

        setSyllabusModule(courseModule);

    };


    const closeSyllabus = () => {

        setSyllabusModule(null);

    };


    // Esc closes the modal
    useEffect(() => {

        if (!syllabusModule) {

            return undefined;

        }

        const onKeyDown = (e) => {

            if (e.key === "Escape") {

                setSyllabusModule(null);

            }

        };

        window.addEventListener("keydown", onKeyDown);

        return () => window.removeEventListener("keydown", onKeyDown);

    }, [syllabusModule]);


    // =====================================================
    // SYLLABUS TOPIC COUNT (syllabus is an array of
    // { topic, duration } rows — the table shows how many)
    // =====================================================

    const getSyllabusCount = (courseModule) => {

        const topics = courseModule.CourseModule_Syllabus;

        return Array.isArray(topics) ? topics.length : 0;

    };


    // =====================================================
    // ADD PAGE VIEW
    // =====================================================
    // Swap the whole list out for the Addcoursemodule page —
    // rendered centered within the page, no modal/backdrop.

    if (addPopupVisible) {

        return (

            <Addcoursemodule
                toggle={hideAddPage}
                onSuccess={handleCourseModuleCreated}
            />

        );

    }


    // =====================================================
    // EDIT PAGE VIEW
    // =====================================================

    if (updatePageVisible && value) {

        return (

            <Updatecoursemodule
                toggle={hideUpdatePage}
                onSuccess={handleCourseModuleUpdated}
                data={value}
            />

        );

    }


    // =====================================================
    // DELETE PAGE VIEW
    // =====================================================

    if (deletePageVisible && value) {

        return (

            <Deletecoursemodule
                toggle={hideDeletePage}
                onSuccess={handleCourseModuleDeleted}
                data={value}
            />

        );

    }


    return (

        <div className="coursemodule-page container-xxl flex-grow-1 container-p-y">


            {/* ================================================= */}
            {/* HEADER */}
            {/* ================================================= */}

            <div className="page-header">

                <div>

                    <h3 className="page-title">
                        Course Module Management
                    </h3>

                    <p className="page-subtitle">
                        Manage all available course modules
                    </p>

                </div>


                <button
                    className="btn btn-primary add-btn"
                    onClick={showAddPage}
                >

                    <i className="bx bx-plus me-2"></i>

                    Add Course Module

                </button>

            </div>


            {/* ================================================= */}
            {/* COURSE MODULE TABLE */}
            {/* ================================================= */}

            <div className="card coursemodule-card">

                <div className="table-responsive">

                    <table className="table modern-table">

                        <thead>

                            <tr>

                                <th>ID</th>

                                <th>
                                    Module Name
                                </th>

                                <th>
                                    Syllabus Topics
                                </th>

                                <th>
                                    Duration
                                </th>


                                <th>
                                    Category
                                </th>

                                <th>
                                    Created Date
                                </th>

                                <th>
                                    Status
                                </th>

                                

                                <th width="180">
                                    Action
                                </th>

                            </tr>

                        </thead>


                        <tbody>

                            {currentCourseModules.length > 0 ? (

                                currentCourseModules.map(
                                    (courseModule) => (

                                        <tr
                                            key={
                                                courseModule.CourseModule_id
                                            }
                                        >

                                            <td>
                                                #{courseModule.CourseModule_id}
                                            </td>


                                            <td>

                                                <strong>
                                                    {
                                                        courseModule.CourseModule_name
                                                    }
                                                </strong>

                                            </td>


                                            <td>

                                                <div className="topic-count-cell">

                                                    <span className="topic-count-badge">
                                                        {
                                                            getSyllabusCount(courseModule)
                                                        }
                                                    </span>

                                                    <button
                                                        type="button"
                                                        className="btn-view-syllabus"
                                                        onClick={() =>
                                                            openSyllabus(
                                                                courseModule
                                                            )
                                                        }
                                                        title="View syllabus"
                                                    >

                                                        <i className="bx bx-show me-1"></i>

                                                        View

                                                    </button>

                                                </div>

                                            </td>
                                            <td>

                                                {
                                                    getTotalDuration(courseModule)
                                                }

                                            </td>



                                            <td>

                                                {
                                                    courseModule.CourseModule_category
                                                }

                                            </td>


                                            <td>

                                                {
                                                    courseModule.Create_date
                                                        ? new Date(
                                                              courseModule.Create_date
                                                          ).toLocaleDateString()
                                                        : "-"
                                                }

                                            </td>


                                            <td>

                                                <button
                                                    type="button"
                                                    className={
                                                        courseModule.CourseModule_Status ===
                                                        "Active"
                                                            ? "status-toggle-btn active"
                                                            : "status-toggle-btn inactive"
                                                    }
                                                    onClick={() =>
                                                        handleToggleStatus(
                                                            courseModule
                                                        )
                                                    }
                                                    title="Click to switch status"
                                                >

                                                    {
                                                        courseModule.CourseModule_Status
                                                    }

                                                </button>

                                            </td>


                                            

                                            <td>

                                                <div className="action-buttons">

                                                    <button
                                                        className="btn btn-edit"
                                                        onClick={() =>
                                                            handleUpdate(
                                                                courseModule
                                                            )
                                                        }
                                                    >
                                                        Edit
                                                    </button>


                                                    <button
                                                        className="btn btn-delete"
                                                        onClick={() =>
                                                            handleDelete(
                                                                courseModule
                                                            )
                                                        }
                                                    >
                                                        Delete
                                                    </button>

                                                </div>

                                            </td>

                                        </tr>

                                    )
                                )

                            ) : (

                                <tr>

                                    <td
                                        colSpan="8"
                                        className="text-center py-4"
                                    >

                                        No course modules found.

                                    </td>

                                </tr>

                            )}

                        </tbody>

                    </table>

                </div>


                {/* ================================================= */}
                {/* PAGINATION */}
                {/* ================================================= */}

                <div className="card-footer bg-white border-0">

                    <div className="d-flex justify-content-end">

                        <button
                            className="btn btn-light me-2"
                            onClick={prevPage}
                            disabled={
                                currentPage === 1
                            }
                        >

                            <i className="bx bx-chevron-left"></i>

                            Previous

                        </button>


                        <button
                            className="btn btn-primary"
                            onClick={nextPage}
                            disabled={
                                indexOfLastItem >=
                                courseModules.length
                            }
                        >

                            Next

                            <i className="bx bx-chevron-right ms-1"></i>

                        </button>

                    </div>

                </div>

            </div>


            {/* ================================================= */}
            {/* SYLLABUS MODAL */}
            {/* ================================================= */}

            {syllabusModule && (

                <div
                    className="modal fade show syllabus-modal"
                    tabIndex="-1"
                    role="dialog"
                    aria-modal="true"
                    style={{
                        display: "block",
                        backgroundColor: "rgba(67, 89, 113, 0.5)"
                    }}
                    onClick={closeSyllabus}
                >

                    <div
                        className="modal-dialog modal-dialog-centered"
                        role="document"
                        onClick={(e) => e.stopPropagation()}
                    >

                        <div className="modal-content">

                            {/* FLOATING CLOSE (X) BUTTON */}
                            <button
                                type="button"
                                className="syllabus-close-btn"
                                aria-label="Close"
                                onClick={closeSyllabus}
                            >
                                <i className="bx bx-x"></i>
                            </button>


                            {/* TITLE */}
                            <div className="syllabus-title-wrap">

                                <span className="syllabus-title-icon">
                                    <i className="bx bx-book-open"></i>
                                </span>

                                <div>

                                    <h5 className="syllabus-modal-title">
                                        {syllabusModule.CourseModule_name} — Syllabus
                                    </h5>

                                    <p className="syllabus-modal-sub">
                                        Topics covered in this course module
                                    </p>

                                </div>

                            </div>


                            {/* TOPIC TABLE */}
                            <div className="syllabus-modal-body">

                                <table className="syllabus-view-table">

                                    <thead>

                                        <tr>

                                            <th width="80">
                                                <i className="bx bx-hash"></i>
                                                No
                                            </th>

                                            <th>
                                                <i className="bx bx-list-ul"></i>
                                                Topic
                                            </th>

                                            <th width="150">
                                                <i className="bx bx-time-five"></i>
                                                Duration
                                            </th>

                                        </tr>

                                    </thead>

                                    <tbody>

                                        {getSyllabusCount(syllabusModule) > 0 ? (

                                            syllabusModule.CourseModule_Syllabus.map(
                                                (row, index) => (

                                                    <tr
                                                        key={
                                                            row.syllabus_id ||
                                                            index
                                                        }
                                                    >

                                                        <td>

                                                            <span className="syllabus-no-badge">
                                                                {
                                                                    row.sequence_no ||
                                                                    index + 1
                                                                }
                                                            </span>

                                                        </td>

                                                        <td>

                                                            <span className="syllabus-topic">

                                                                <i className="bx bx-bookmark"></i>

                                                                {row.topic}

                                                            </span>

                                                        </td>

                                                        <td>

                                                            <span className="syllabus-duration-pill">

                                                                <i className="bx bx-time-five"></i>

                                                                {
                                                                    formatTopicDuration(
                                                                        row.duration
                                                                    )
                                                                }

                                                            </span>

                                                        </td>

                                                    </tr>

                                                )
                                            )

                                        ) : (

                                            <tr>

                                                <td
                                                    colSpan="3"
                                                    className="syllabus-empty"
                                                >

                                                    <i className="bx bx-folder-open"></i>

                                                    <div>
                                                        No syllabus topics added.
                                                    </div>

                                                </td>

                                            </tr>

                                        )}

                                    </tbody>

                                </table>

                            </div>


                            {/* TOTALS + CLOSE BUTTON */}
                            <div className="syllabus-modal-footer">

                                <div className="syllabus-totals">

                                    <div className="syllabus-stat topics">

                                        <span className="syllabus-stat-icon">
                                            <i className="bx bx-list-check"></i>
                                        </span>

                                        <div>

                                            <span className="syllabus-total-label">
                                                Total Topics
                                            </span>

                                            <span className="syllabus-total-value">
                                                {getSyllabusCount(syllabusModule)}
                                            </span>

                                        </div>

                                    </div>


                                    <div className="syllabus-stat duration">

                                        <span className="syllabus-stat-icon">
                                            <i className="bx bx-timer"></i>
                                        </span>

                                        <div>

                                            <span className="syllabus-total-label">
                                                Total Duration
                                            </span>

                                            <span className="syllabus-total-value">
                                                {getTotalDuration(syllabusModule)}
                                            </span>

                                        </div>

                                    </div>

                                </div>


                                <button
                                    type="button"
                                    className="syllabus-cancel-btn"
                                    onClick={closeSyllabus}
                                >
                                    Close
                                </button>

                            </div>

                        </div>

                    </div>

                </div>

            )}

        </div>

    );

}


export default CourseModule;
